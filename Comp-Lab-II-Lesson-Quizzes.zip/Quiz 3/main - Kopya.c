//Göksel Okandan
//210201058
//Quiz 03

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

void YearMonthDayConverter(int DaysToConvert, int *YearToConvert, int *MonthToConvert, int *WeekToConvert ,int *DayToConvert){
    if(((((DaysToConvert/365)+1)%4)==0)){
        *YearToConvert=DaysToConvert/366;
        DaysToConvert=DaysToConvert-*YearToConvert*366;
        *MonthToConvert=DaysToConvert/30;
        DaysToConvert=DaysToConvert-*MonthToConvert*30;
        *WeekToConvert=DaysToConvert/7;
        DaysToConvert=DaysToConvert-*WeekToConvert*7;
        *DayToConvert=DaysToConvert;
    }
    else
    *YearToConvert=DaysToConvert/365;
    DaysToConvert=DaysToConvert-*YearToConvert*365;
    *MonthToConvert=DaysToConvert/30;
    DaysToConvert=DaysToConvert-*MonthToConvert*30;
    *WeekToConvert=DaysToConvert/7;
    DaysToConvert=DaysToConvert-*WeekToConvert*7;
    *DayToConvert=DaysToConvert;
}

int main(){
    int hesaplanacakgun;
    int year,month,week,day;

    ENTERGUNSAYISI:
    printf("Hesaplanacak Gun Sayisini Giriniz.\n");
    scanf("%d",&hesaplanacakgun);

    if(hesaplanacakgun<=0){
        printf("Lutfen Pozitif Bir Sayi Giriniz.\n\n");
        goto ENTERGUNSAYISI;
    }

    YearMonthDayConverter(hesaplanacakgun,&year,&month,&week,&day);

    printf("%d Gun == %d Yil - %d Ay - %d Hafta - %d Gun",hesaplanacakgun,year,month,week,day);
}
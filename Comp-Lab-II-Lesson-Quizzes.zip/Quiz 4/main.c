//Göksel Okandan
//210201058
//Quiz 04

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

int main(){
    
}